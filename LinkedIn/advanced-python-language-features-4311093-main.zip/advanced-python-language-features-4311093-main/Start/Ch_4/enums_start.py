# Example file for Advanced Python: Language Features by Joe Marini
# define enumerations using the Enum base class


# TODO: enums have human-readable values and types

# TODO: enums have name and value properties

# TODO: print the auto-generated value

# TODO: enums are hashable - can be used as keys
