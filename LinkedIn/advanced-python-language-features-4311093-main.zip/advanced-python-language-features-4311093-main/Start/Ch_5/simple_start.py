# Example file for Advanced Python: Language Features by Joe Marini
# Simple pattern matching using literal values

x = 0

# TODO: Literal patterns are explicit values: integers, strings, Booleans, etc
